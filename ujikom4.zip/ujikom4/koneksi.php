<?php
$host = mysqli_connect("localhost","root","","db_rs4");
?>