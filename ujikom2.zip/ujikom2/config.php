<?php
//using mysqli_connect for database connection
$koneksi =  mysqli_connect("localhost","root","","db_rs2");

if (mysqli_connect_errno()){
    echo "Koneksi ke database gagal : " . mysqli_conect_error();
}
?>