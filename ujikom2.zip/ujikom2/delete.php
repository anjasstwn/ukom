<?php
include_once ("config.php");
$id = $_GET['id'];

$result = mysqli_query($koneksi,"DELETE from users where id=$id");
header ("Location:index.php");
?>