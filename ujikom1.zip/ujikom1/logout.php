<?php
//mengaktifkan session
session_start();

//menghapus semua session
session_destroy();

//mengalihkan halaman sambil mengirim pesan logut
header("location:index.php?pesan=logout");
?>