<html>
<head> 
    <title>Halaman Login - www.anjasstwn.site </title>
</head>
<body>
    <center>
    <h2>Login - www.anjasstwn.site </h2>
<!-- cek pesan notifikasi -->
<?php
if (isset($_GET['pesan'])){
    if($_GET['pesan'] == "gagal"){
        echo "Login gagal! username dan password salah!";
    } else if ($_GET['pesan'] == "logut"){
        echo "Anda telah berhasil logut";
    } else if($_GET['pesan'] == "belum_login"){
        echo "Anda harus login";
    }
}
?>
<br/>
<form method ="post" action="cek_login.php">
    <table>
        <tr>
            <td>Username</td>
            <td>:</td>
            <td><input type ="text" name="username" placeholder="Masukan username"></td>
</tr>
<tr>
    <td>Password</td>
    <td>:</td>
    <td><input type="password" name="password" placeholder="Masukkan password"></td>
</tr>
<tr>
    <td></td>
    <td></td>
    <td><input type="submit" value="login"></td>
</tr>
</table;>
</form>
</center>
</body>
</html>