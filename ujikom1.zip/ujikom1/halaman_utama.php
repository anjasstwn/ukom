<html>
<head>
    <title> Halaman Utama - www.anjasstwn.site</title>
</head>
<body>
    <center>
    <h2>Halaman Utama - www.anjasstwn.site</h2>
    <h2>Selamat Datang di Menu Utama</h2>
    <br/>
    <a href = "dokter.php">Form Data Dokter </a></br>
    <a href = "logout.php">Logout</a><br/>
    </center>
</body>
</html>