<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "db_rs3";

$pdo = new PDO('mysql:host='.$host.';dbname='.$database, $username, $password);
?>