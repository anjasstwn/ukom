<html>
<head>
	<title>Halaman Utama</title>
</head>
<body>
	<center>
	<h2>Selamat Datang Di Menu Utama</h2>
	<br/>
	<a href="dokter.php">Form Data Dokter</a><br/>
	<a href="logout.php">Logout</a><br/>
	</center>
</body>
</html>