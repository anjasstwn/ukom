<?php
//mengaktifkan session php
session_start();

//menghubungkan dengan koneksi
include 'koneksi.php';

//menangkap data yang dikirimkan dari form
$username = $_POST['username'];
$password = $_POST['password'];

//menyeleksi data admin dengan username dan password yang seusai

$data = mysqli_query($koneksi,"select * from admin where username='$username' and password='$password'");

//menghirtung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);

if($cek > 0) {
    $_SESSION['username'] = $username;
    $_SESSION['status'] = "login";
    header("location:halaman_utama.php");
}else{
    header("location:index.php?pesan=gagal");
}
?>

