<html>
<head>
<title>Pendaftaran Siswa Baru | Universitas Pamulang </title>
</head>

<body>
<header>
<h3>Pendaftaran Mahasiswa Baru</h3>
<h1>Universitas Pamulang</h1>
</header>

<h4>Menu</h4>
<nav>
<ul>
<li><a href="form-daftar.php">Daftar Baru</a></li>
<li><a href="list-siswa.php">Pendaftar</a></li>
</ul>
</nav>
</body>
</html>
